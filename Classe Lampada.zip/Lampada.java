public class Lampada {

	boolean status;
	
	public void ligar() {
		status = true;
	}
	
	public void desligar() {
		status = false;
	}
	
	public void observar() {
		if (status) {
			System.out.println("A lampada esta ligada");
		}
		else {
			System.out.println("A lamapda esta desligada");
		}
	}
}
