
public class UsaLampada {

	public static void main(String[] args) {
		
		Lampada l1 = new Lampada();
		
		Lampada l2 = new Lampada();
		
		l1.ligar();
		l2.desligar();
		
		l1.observar();
		l2.observar();
		
		l2.ligar();
		l2.observar();
	}

}
