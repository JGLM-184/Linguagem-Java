package aula1504;

public class Principal {

	public static void main(String[] args) {
		
		Pessoa p = new Pessoa("Joao");
		/*
		System.out.println("Nome: "+p.getNome());
		*/
		
		System.out.println();
		
		Fisica f = new Fisica("Gabriel","123456789-10");
		/*
		 * 
		System.out.println("Nome: "+f.getNome());
		System.out.println("CPF: "+f.getCpf());
		*/
		
		System.out.println();
		
		p.mostrar();
		f.mostrar();
		
		System.out.println();
		
		p.imprimir();
		f.imprimir();
		
	
		
	}
}
