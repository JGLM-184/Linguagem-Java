package aula1504;

public class Fisica extends Pessoa{
	
	private String cpf;
	
	public Fisica() {
		
	}
		
	public Fisica(String nome, String cpf) {
		super(nome);
		this.cpf = cpf;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	//override
	public void mostrar() {
		System.out.println("Sou a filha");
	}
	
	
	public void imprimir() {
		super.imprimir();
		System.out.println("CPF: "+cpf);
	}

}
