package aula1504;

public class Pessoa {
	
	private String nome;
	
	public Pessoa() {
		
	}
	
	
	public Pessoa(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void mostrar() {
		System.out.println("Sou a mae");
	}
	
	public void imprimir() {
		System.out.println("Nome: "+nome);
	}

	

}
