package aula0104;

public class TestaPiloto {

	public static void main(String[] args) {
		
		Piloto p1 = new Piloto("Joao");
		p1.adicionaHoras(250);
		p1.imprimir();
		
		
		System.out.println();
		
		Piloto p2 = new Piloto("Amanda");
		p2.adicionaHoras(2);
		p2.imprimir();
		
	}

}
