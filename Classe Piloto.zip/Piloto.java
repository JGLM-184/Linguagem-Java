package aula0104;

public class Piloto {

	private String nome;
	private int horas;
	
	public Piloto(String nome) {
		this.nome = nome;
		horas = 0;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void adicionaHoras(int qntd) {
		horas = qntd;
	}
	
	public void imprimir() {
		
		System.out.println("Nome piloto: "+nome+"\nHoras: "+horas);
		
		if (horas <= 200) {
			System.out.println("Tipo piloto: co-piloto");
		}
		else {
			System.out.println("Tipo piloto: comandante");
		}
	}
}
