package aula1103;

public class App1 {

	public static void main(String[] args) {
		
		int valor[] = {34, 4, 6, 7, 22, 34, 5, 7, 8, 9};
		
		//for each
		for (int v : valor) {
			System.out.println(v);
		}
		
		
		
		

	}

}
