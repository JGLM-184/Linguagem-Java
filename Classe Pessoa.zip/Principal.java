package aula1103;

public class Principal {

	public static void main(String[] args) {
		
		Pessoa p = new Pessoa();
		
		p.nome = "José";
		p.cpf = 12345678;
		
		System.out.println("Nome: "+p.nome+"   CPF: "+p.cpf);

	}

}