package aula1103;

public class Pessoa {
	
	//atributos
	int cpf;
	String nome;

}
