public class Conta {
	
	double saldo;
	String nrAgencia;
	String titular;
	String nrConta;
	int codBanco;

}
