public class Agencia {
	String nrAgencia;
	int codBanco;
	

}
