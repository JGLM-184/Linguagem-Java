public class TestaAgencia {

	public static void main(String[] args) {
		
		Agencia a = new Agencia();
		
		a.nrAgencia = "1";
		a.codBanco = 234;
		
		System.out.println("* -----------------------------");
		System.out.println("* AGENCIA: "+a.nrAgencia);
		System.out.println("* BANCO: "+a.codBanco);
		System.out.println("* -----------------------------");


	}

}
