
public class TestarAnimais {

	public static void main(String[] args) {
		
		Mamifero camelo = new Mamifero("Camelo",150,4,"Amarelo","Terra", 2, null);
		camelo.mostrarMamifero();
		
		System.out.println();
		
		Peixe tubarao = new Peixe("Tubarão",300,0,"Cinzento","Mar", 1.5f, "Barbatanas e cauda");
		tubarao.mostrarPeixe();

		System.out.println();

		Mamifero ursocanada = new Mamifero("Urso-do-canadá",180, 4,"Vermelho","Terra", 0.5f, "Mel");
		ursocanada.mostrarMamifero();
		
		
	}

}
