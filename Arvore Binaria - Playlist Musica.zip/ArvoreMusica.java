class ArvoreMusica {
    NoMusica raiz;

    public ArvoreMusica() {
        this.raiz = null;
    }
    
    // Métodos para inserir música
    public void inserir(Musica musica) {
        raiz = inserirRec(raiz, musica);
    }

    // Método recursivo para auxílio na inserção
    private NoMusica inserirRec(NoMusica noAtual, Musica musica) {
        if (noAtual == null)
            return new NoMusica(musica);
        else if (musica.popularidade > noAtual.musica.popularidade)
            noAtual.direita = inserirRec(noAtual.direita, musica);
        else
            noAtual.esquerda = inserirRec(noAtual.esquerda, musica);
        return noAtual;
    }
    
    

    // Método para recomendar músicas com base em uma informada
    public void recomendar(Musica musica) {
        System.out.println("\n\nRecomendações com base no gênero '"+musica.genero+"', da música '"+musica.nome+"' solicitada:");
        recomendarRec(raiz, musica);
    }
    
    // Método recursivo para auxílio na recomendação
    private void recomendarRec(NoMusica noAtual, Musica musica) {
        if (noAtual == null) 
            return;
        recomendarRec(noAtual.esquerda, musica);
        if (noAtual.musica.genero.equals(musica.genero) && !noAtual.musica.equals(musica)) { 
            System.out.println("  - "+noAtual.musica + " ");
        }
        recomendarRec(noAtual.direita, musica);
    }

}
