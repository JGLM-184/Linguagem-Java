
public class Main
{
	public static void main(String[] args) {
	    
	    //Criação das músicas
	    Musica lp1 = new Musica("Waiting For The End","Rock",1000);
	    Musica lp2 = new Musica("Breaking The Habit","Rock",554);
	    Musica lp3 = new Musica("Numb","Rock",1250);
	    Musica lp4 = new Musica("Iridescent","Rock",445);
	    
	    Musica hk1 = new Musica("The Grimm Troupe","OST Jogo",1564);
	    Musica hk2 = new Musica("Sealed Vessel","OST Jogo",874);
	    Musica hk3 = new Musica("City of Tears","OST Jogo",1690);
	    Musica hk4 = new Musica("Sisters of Battle","OST Jogo",79);
	    
	    Musica eve1 = new Musica("Dramaturgy","J-Rock",722);
	    Musica eve2 = new Musica("Last Dance","J-Rock",1141);
	    Musica eve3 = new Musica("Outsider","J-Rock",60);
	    Musica eve4 = new Musica("KaiKai Kitan","J-Rock",21);
	    
	    Musica aot1 = new Musica("TRAITOR","OST Animação",1183);
	    Musica aot2 = new Musica("Ashes on the Fire","OST Animação",1124);
	    Musica fr1 = new Musica("Zoltraak","OST Animação",75);
	    Musica fr2 = new Musica("Frieren the Slayer","OST Animação",1500);
	    
	    //Criação da árvore binária
	    ArvoreMusica minhaPlayList = new ArvoreMusica();
	    
	    //Inserção de músicas na árvore
	    minhaPlayList.inserir(lp1);
	    minhaPlayList.inserir(lp2);
	    minhaPlayList.inserir(lp3);
	    minhaPlayList.inserir(lp4);
	    minhaPlayList.inserir(hk1);
	    minhaPlayList.inserir(hk2);
	    minhaPlayList.inserir(hk3);
	    minhaPlayList.inserir(hk4);
	    minhaPlayList.inserir(eve1);
	    minhaPlayList.inserir(eve2);
	    minhaPlayList.inserir(eve3);
	    minhaPlayList.inserir(eve4);
	    minhaPlayList.inserir(aot1);
	    minhaPlayList.inserir(aot2);
	    minhaPlayList.inserir(fr1);
	    minhaPlayList.inserir(fr2);
	    
	    //Utilização do método de recomendação
	    minhaPlayList.recomendar(lp1);
	    minhaPlayList.recomendar(hk1);
	    minhaPlayList.recomendar(eve1);
	    minhaPlayList.recomendar(aot1);
	    
	   
	}
}