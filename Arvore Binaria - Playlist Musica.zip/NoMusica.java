public class NoMusica {
    Musica musica;
    NoMusica esquerda;
    NoMusica direita;
    
    NoMusica (Musica m) {
        musica = m;
        esquerda = null;
        direita = null;
    }
    
    @Override
    public String toString() {
        String s = "";
        s = s + musica;
        return s;
    }
}