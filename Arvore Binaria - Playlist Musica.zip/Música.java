class Musica {
    // Atributos da música:
    String nome;
    String genero;
    int popularidade;

    // Construtor da classe Musica:
    public Musica(String nome, String genero, int popularidade) {
        this.nome = nome;
        this.genero = genero;
        this.popularidade = popularidade;
    }
    
    @Override
    public String toString() {
        return nome+" - "+genero+" - "+popularidade;
    }
}
