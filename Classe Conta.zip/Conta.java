public class Conta {
	
	double saldo;
	String nrAgencia;
	String titular;
	String nrConta;
	int codBanco;

	
	public Conta(double saldo, String nrAgencia, String titular, String nrConta, int codBanco) {
		super();
		this.saldo = saldo;
		this.nrAgencia = nrAgencia;
		this.titular = titular;
		this.nrConta = nrConta;
		this.codBanco = codBanco;
	}


	public Conta() {
	}
	
	
	public void saque(double valor) {
		if (valor < 0) {
			System.out.println("Nao foi possivel realizar o saque, por favor informe um valor positivo");
		}
		else if (valor > 0 && saldo >= valor) {
			saldo = saldo - valor; 
		}
		else if (valor > 0 && saldo < valor) {
			System.out.println("Saldo insuficiente, nao foi possivel sacar R$"+valor);
		}
	}
	
	
	public void deposito(double valor) {
		if (valor < 0) {
			System.out.println("Nao foi possivel realizar o deposito, por favor informe um valor positivo");
		}
		else {
			saldo = saldo + valor;
		}
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void imprimeDados() {
		System.out.println("\n----------------------------");
		System.out.println("AGENCIA:"+nrAgencia+"  BANCO: "+codBanco);
		System.out.println("Conta: "+nrConta);
		System.out.println("TITULAR: "+titular);
		System.out.println("SALDO: "+saldo);
		System.out.println("-----------------------------\n");
	}
	
	

}
