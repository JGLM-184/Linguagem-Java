
public class TestaConta {

	public static void main(String[] args) {
		
		
		Conta conta1 = new Conta(1000,"123","Joao","600",1);
		
		conta1.imprimeDados();

		conta1.saque(-100);
		conta1.imprimeDados();
		conta1.deposito(10);
		conta1.imprimeDados();
		System.out.println("aaaa"+conta1.getSaldo());



	}

}
