
public class PrincipalEleitoral {

	public static void main(String[] args) {

		Eleitoral el = new Eleitoral("Joao",20);
		
		el.imprimir();
		
		el.verificar();

	}

}
