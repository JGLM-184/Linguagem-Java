
public class Principal {

	public static void main(String[] args) {
		
		Computador pc1 = new Computador();
		pc1.marca = "HP";
		pc1.cor = "Preto";
		pc1.modelo = "A1020";
		pc1.serie = "100";
		pc1.valor = 1500;

		pc1.imprimirDados();
		
		
		System.out.println();
		
		
		Computador pc2 = new Computador("HP","Preto","A1020","100",1500);
		pc2.imprimirDados();
		
		
		
	}

}
