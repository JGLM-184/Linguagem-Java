public class Computador {
	String marca;
	String cor;
	String modelo;
	String serie;
	double valor;
	
	
	
	public Computador(String marca, String cor, String modelo, String serie, double valor) {
		this.marca = marca;
		this.cor = cor;
		this.modelo = modelo;
		this.serie = serie;
		this.valor = valor;
	}
	
	
	
	public Computador() {
		
	}



	public void imprimirDados() {
		System.out.println("Marca: "+marca);
		System.out.println("Cor: "+cor);
		System.out.println("Modelo: "+modelo);
		System.out.println("Serie: "+serie);
		System.out.println("Valor: R$"+valor);
	}
	
}
