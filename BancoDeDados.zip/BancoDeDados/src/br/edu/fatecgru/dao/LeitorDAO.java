package br.edu.fatecgru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.edu.fatecgru.model.Leitor;
import br.edu.fatecgru.util.ConnectionFactory;

public class LeitorDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	private Leitor leitor;

	public LeitorDAO() throws Exception {
		
		// chama a classe ConnectionFactory e estabele uma conexão
		try {
			this.conn = ConnectionFactory.getConnection();
		} catch (Exception e) {
			throw new Exception("erro: \n" + e.getMessage());
		}
	}
	
	// método de salvar
	public void salvar(Leitor leitor) throws Exception {
		if (leitor == null)
			throw new Exception("O valor passado nao pode ser nulo");
		try {
			String SQL = "INSERT INTO tbLeitor (codLeitor, nomeLeitor, tipoLeitor) values (?, ?, ?)";
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, leitor.getCodLeitor());
			ps.setString(2, leitor.getNomeLeitor());
			ps.setString(3, leitor.getTipoLeitor());
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao inserir dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}
/*
	//método de atualizar
	public void alterar(Leitor leitor) throws Exception {
		if (leitor == null)
			throw new Exception("O valor passado nao pode sernulo");
		try {
			String SQL = "UPDATE tbLeitor set nomeLeitor=?,tipoLeitor=? WHERE codLeitor = ?";
			ps = conn.prepareStatement(SQL);
			ps.setString(1, leitor.getNomeLeitor());
			ps.setString(2, leitor.getTipoLeitor());
			ps.setInt(3, leitor.getCodLeitor());
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao alterar dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}

	//método de excluir
	public void excluir(int codLeitor) throws Exception {
		try {
			String SQL = "DELETE FROM tbLeitor WHERE codLeitor =?";
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, codLeitor);
			ps.executeUpdate();
		} catch (SQLException sqle) {
			throw new Exception("Erro ao excluir dados " + sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps);
		}
	}
	
	// Consultar Leitor
	public Leitor consultar(int codLeitor) throws Exception {
		try {
			String SQL = "SELECT * FROM tbLeitor WHERE codLeitor=?";
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, codLeitor);
			rs = ps.executeQuery();
			if (rs.next()) {
				int codigo = rs.getInt(1);
				String nome = rs.getString(2);
				String tipo = rs.getString(3);
				leitor = new Leitor(codigo, nome, tipo);
			}
			return leitor;
		} catch (SQLException sqle) {
			throw new Exception(sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps, rs);
		}
	}

	// Listar todos
	public List listarTodos() throws Exception {
		try {
			ps = conn.prepareStatement("SELECT * FROM tbLeitor");
			rs = ps.executeQuery();
			List<Leitor> list = new ArrayList<Leitor>();
			while (rs.next()) {
				int codLeitor = rs.getInt("codLeitor");
				String nomeLeitor = rs.getString("nomeLeitor");
				String tipoLeitor = rs.getString("tipoLeitor");
				list.add(new Leitor(codLeitor, nomeLeitor, tipoLeitor));
			}
			return list;
		} catch (SQLException sqle) {
			throw new Exception(sqle);
		} finally {
			ConnectionFactory.closeConnection(conn, ps, rs);
		}
	}*/
}