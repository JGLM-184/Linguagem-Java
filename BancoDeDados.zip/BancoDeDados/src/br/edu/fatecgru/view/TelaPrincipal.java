package br.edu.fatecgru.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import br.edu.fatecgru.dao.LeitorDAO;
import br.edu.fatecgru.model.Leitor;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField txtCodigoLeitor;
	private JTextField txtNomeLeitor;
	private JComboBox cmbTipoLeitor;
	private JButton btnNovo;
	private JButton btnSalvar;
	private JButton btnConsultar;
	private JButton btnListar;
	private JButton btnAlterar;
	private JLabel lblMensagem;
	private TextArea txtListar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setTitle("Manutenção Leitor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 627, 485);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Código do leitor");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 29, 126, 28);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Nome do leitor");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(10, 79, 126, 28);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Tipo do leitor");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(10, 124, 126, 28);
		contentPane.add(lblNewLabel_2);
		
		txtCodigoLeitor = new JTextField();
		txtCodigoLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtCodigoLeitor.setBounds(172, 29, 423, 28);
		contentPane.add(txtCodigoLeitor);
		txtCodigoLeitor.setColumns(10);
		
		txtNomeLeitor = new JTextField();
		txtNomeLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtNomeLeitor.setBounds(172, 77, 423, 32);
		contentPane.add(txtNomeLeitor);
		txtNomeLeitor.setColumns(10);
		
		cmbTipoLeitor = new JComboBox();
		cmbTipoLeitor.setModel(new DefaultComboBoxModel(new String[] {"Selecione uma opção:", "Aluno", "Professor", "Administrador"}));
		cmbTipoLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		cmbTipoLeitor.setBounds(172, 122, 423, 32);
		contentPane.add(cmbTipoLeitor);
		
		btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//------------------------------
					txtNomeLeitor.setText(null);
					txtCodigoLeitor.setText(null);
					lblMensagem.setText(null);
					cmbTipoLeitor.setSelectedIndex(0);
				//------------------------------
			}
		});
		btnNovo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNovo.setBounds(10, 181, 89, 23);
		contentPane.add(btnNovo);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//------------------------------
				
					try {
						Leitor leitor = new Leitor();
						leitor.setCodLeitor(Integer.parseInt(txtCodigoLeitor.getText()));
						leitor.setNomeLeitor(txtNomeLeitor.getText());
						leitor.setTipoLeitor((String)cmbTipoLeitor.getSelectedItem());
						
						//Abrir o bd
						LeitorDAO dao = new LeitorDAO();
						
						//salvar
						dao.salvar(leitor);
						lblMensagem.setText("Salvo com sucesso!");					
					} catch (Exception e1) {
						lblMensagem.setText(e1.getMessage());
					}
				//------------------------------
			}
		});
		btnSalvar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSalvar.setBounds(109, 181, 89, 23);
		contentPane.add(btnSalvar);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnConsultar.setBounds(208, 181, 103, 23);
		contentPane.add(btnConsultar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnExcluir.setBounds(407, 181, 89, 23);
		contentPane.add(btnExcluir);
		
		btnListar = new JButton("Listar");
		btnListar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnListar.setBounds(506, 181, 89, 23);
		contentPane.add(btnListar);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnAlterar.setBounds(321, 181, 76, 23);
		contentPane.add(btnAlterar);
		
		lblMensagem = new JLabel("");
		lblMensagem.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMensagem.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, new Color(0, 0, 0), null));
		lblMensagem.setBounds(10, 410, 585, 25);
		contentPane.add(lblMensagem);
		
		txtListar = new TextArea();
		txtListar.setBounds(10, 244, 589, 160);
		contentPane.add(txtListar);
	}
}
